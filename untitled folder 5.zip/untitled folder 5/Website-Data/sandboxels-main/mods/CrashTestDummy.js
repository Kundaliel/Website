// This new crashtestdummy mod will be more used for code that I'm not sure will actually work
elements.sandreplacer = {
    color: "#ff80ff",
    tool: function(pixel) {
        pixel.element = "sand"
    },
    category: "tools",
};
