Contributions to the main index.html file will be ignored. Use this repository to officially publish your Sandboxels mods.
