import "regenerator-runtime/runtime";
global.$ = require("jquery");
