(function() {
    'use strict';

    window.addEventListener('load', function() {
        var headings = document.getElementsByTagName('h5');
        for (var i = 0; i < headings.length; i++) {
            if (headings[i].textContent.includes('Dev Speed:')) {
                headings[i].textContent = headings[i].textContent.replace('Dev Speed:', 'Warped Time:');
                break;
            }
        }
    });
})();
