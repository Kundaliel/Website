<div style="text-align:center"><img src="data/favicon.png"/></div>

# <center>The Prestreestuck</center>
made by ducdat0507  

a mod of The Prestige Tree by Jacorb and Aarex  
using The Modding Tree by Acamaeda  
based on Homestuck by Andrew Hussie (of course)  

You can play it [here](https://ducdat0507.github.io/prestreestuck/).  
There's also a bonus TMT modfinder [here](https://ducdat0507.github.io/prestreestuck/finder.html).