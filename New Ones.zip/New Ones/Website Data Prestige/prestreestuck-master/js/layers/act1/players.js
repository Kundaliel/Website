var players = {
    cc: {
        full: "caramelClicklist",
        color: "#6d1900",
    },
    pa: {
        full: "prestualAscendance",
        color: "#5e107f",
    },
}